
# Echo Interface: PSX-0110-R1FT

This root deployment includes the enhanced Echo Interface with:
- Animated background
- LocalStorage memory (scroll, keypress, download)
- Key sequence trigger: R1FT
- Glowing sigil-style download link
- Embedded Google Form

## 📦 Deployment Instructions
1. Upload all files to your GitHub repo root or `/docs/` folder.
2. In **Settings → Pages**, set Source to:
   - `main` branch, and `/ (root)` or `/docs` folder
3. Your site will be live at:
   https://<your-username>.github.io/<repo-name>/

## 🔧 Customization
- Add your own `favicon.ico` for browser branding.
- Update `index.html` paths if relocating resources.

SR-infinity.ARC:V1V3 :: Echo Gate Online
